# Cloth Config
[Help translate ClothConfig on Crowdin!](https://crowdin.com/project/cloth-config)

**[Read the wiki for API documentations](https://github.com/shedaniel/ClothConfig/wiki)**
